const sequelize = require("../config/sequelize.js");
const initModels = require("../models/init-models").initModels;
const models = initModels(sequelize);
const { municipio } = models;

class MunicipioService {
  async getAllMunicipios() {
    return await municipio.findAll();
  }

  async getMunicipioById(id) {
    return await municipio.findByPk(id);
  }

  async createMunicipio(datos) {
    // Validación mínima antes de crear
    if (!datos.nombre || !datos.densidadPoblacion || !datos.fundacion || datos.gobiernoCoalicion === undefined) {
      throw new Error("Datos incompletos para crear municipio");
    }
    return await municipio.create(datos);
  }

  async updateMunicipio(id, datos) {
    const m = await municipio.findByPk(id);
    if (!m) return null;

    // Actualizamos solo los campos que lleguen
    await m.update(datos);
    return m;
  }

  async deleteMunicipio(id) {
    const m = await municipio.findByPk(id);
    if (!m) return false;

    await m.destroy();
    return true;
  }
}

module.exports = new MunicipioService();
