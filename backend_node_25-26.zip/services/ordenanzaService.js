// Servicio para interactuar con el modelo Sequelize `ordenanza`

// Recuperar función de inicialización de modelos
const initModels = require("../models/init-models.js").initModels;
// Crear la instancia de sequelize con la conexión a la base de datos
const sequelize = require("../config/sequelize.js");
// Cargar las definiciones del modelo en sequelize
const models = initModels(sequelize);
// Recuperar el modelo movie
const Ordenanza = models.ordenanza;
const Municipio = models.municipio;

class OrdenanzaService {
  async getAllOrdenanzas() {
    // Devuelve todas las ordenanzas.
    const result = await Ordenanza.findAll({
      include: [
        {
          model: Municipio,
          as: "municipioData",
        },
      ],
    });
    return result;
  }

  async getOrdenanzaById(id_ordenanza) {
    // Devuelve una ordenanza por su id
    const result = await Ordenanza.findByPk(id_ordenanza);
    return result;
  }

  async createOrdenanza(datosOrdenanza) {
    // Crea una nueva ordenanza
    const newOrdenanza = await Ordenanza.create(datosOrdenanza);
    return newOrdenanza;
  }

  async updateOrdenanza(id_ordenanza, datosOrdenanza) {
    // Actualiza una ordenanza existente
    const ordenanza = await Ordenanza.findByPk(id_ordenanza);
    if (ordenanza) {
      await ordenanza.update(datosOrdenanza);
      return ordenanza;
    }
    return null;
  }

  async deleteOrdenanza(id_ordenanza) {
    // Elimina una ordenanza por su id
    const ordenanza = await Ordenanza.findByPk(id_ordenanza);
    if (ordenanza) {
      await ordenanza.destroy();
      return true;
    }
    return false;
  }
}

module.exports = new OrdenanzaService();
