// index.js
const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors()); 
app.use(express.json());


// Configuración de la BD
const sequelize = require("./config/sequelize");

// Inicializar modelos y relaciones
require("./models/init-models")(sequelize);

// Rutas
const municipioRoutes = require("./routes/municipioRoutes");
const ordenanzaRoutes = require("./routes/ordenanzaRoutes");

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas principales
app.use("/municipios", municipioRoutes);
app.use("/ordenanzas", ordenanzaRoutes);

// Ruta raíz
app.get("/", (req, res) => {
  res.json({
    mensaje: "API REST de Municipios y Ordenanzas operativa 🚀",
  });
});

// Middleware de errores
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    error: "Error interno del servidor",
  });
});

// Arranque del servidor
const PORT = process.env.PORT || 3001;

sequelize
  .authenticate()
  .then(() => {
    console.log("✅ Conectado a MySQL correctamente");
    app.listen(PORT, () => {
      console.log(`🚀 Servidor escuchando en http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error("❌ Error al conectar con la base de datos:", error);
  });
