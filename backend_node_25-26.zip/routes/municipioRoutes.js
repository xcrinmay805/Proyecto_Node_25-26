const express = require("express");
const router = express.Router();
const municipioController = require("../controllers/municipioController");

// Todas las rutas apuntan directamente a las funciones
router.get("/", municipioController.getAllMunicipios);
router.post("/", municipioController.createMunicipio);
router.get("/:id", municipioController.getMunicipioById);
router.put("/:id", municipioController.updateMunicipio);
router.delete("/:id", municipioController.deleteMunicipio);

module.exports = router;
