// routes/ordenanzaRoutes.js
const express = require("express");
const router = express.Router();
const ordenanzaController = require("../controllers/ordenanzaController");

// Rutas para Ordenanzas
router.get("/", ordenanzaController.getAllOrdenanzas.bind(ordenanzaController));       // GET /ordenanzas
router.get("/:id", ordenanzaController.getOrdenanzaById.bind(ordenanzaController));   // GET /ordenanzas/:id
router.post("/", ordenanzaController.createOrdenanza.bind(ordenanzaController));      // POST /ordenanzas
router.put("/:id", ordenanzaController.updateOrdenanza.bind(ordenanzaController));    // PUT /ordenanzas/:id
router.delete("/:id", ordenanzaController.deleteOrdenanza.bind(ordenanzaController)); // DELETE /ordenanzas/:id

module.exports = router;
