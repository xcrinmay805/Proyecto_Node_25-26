const { logMensaje } = require("../utils/logger.js");
const municipioService = require("../services/municipioService");

class MunicipioController {
  async getAllMunicipios(req, res) {
    try {
      const municipios = await municipioService.getAllMunicipios();
      return res.status(200).json({
        ok: true,
        datos: municipios,
        mensaje: "Municipios recuperados correctamente",
      });
    } catch (err) {
      logMensaje("Error en getAllMunicipios:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al recuperar municipios",
      });
    }
  }

  async getMunicipioById(req, res) {
    const id = req.params.id;
    try {
      const m = await municipioService.getMunicipioById(id);
      if (!m) {
        return res.status(404).json({
          ok: false,
          datos: null,
          mensaje: "Municipio no encontrado",
        });
      }
      return res.status(200).json({
        ok: true,
        datos: m,
        mensaje: "Municipio recuperado correctamente",
      });
    } catch (err) {
      logMensaje("Error en getMunicipioById:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al recuperar el municipio",
      });
    }
  }

  async createMunicipio(req, res) {
    const datos = req.body;
    try {
      const nuevo = await municipioService.createMunicipio(datos);
      return res.status(201).json({
        ok: true,
        datos: nuevo,
        mensaje: "Municipio creado correctamente",
      });
    } catch (err) {
      logMensaje("Error en createMunicipio:", err);
      return res.status(400).json({
        ok: false,
        datos: null,
        mensaje: "Error al crear el municipio: " + err.message,
      });
    }
  }

  async updateMunicipio(req, res) {
    const id = req.params.id;
    const datos = req.body;
    try {
      const actualizado = await municipioService.updateMunicipio(id, datos);
      if (!actualizado) {
        return res.status(404).json({
          ok: false,
          datos: null,
          mensaje: "Municipio no encontrado",
        });
      }
      return res.status(200).json({
        ok: true,
        datos: actualizado,
        mensaje: "Municipio actualizado correctamente",
      });
    } catch (err) {
      logMensaje("Error en updateMunicipio:", err);
      return res.status(400).json({
        ok: false,
        datos: null,
        mensaje: "Error al actualizar el municipio: " + err.message,
      });
    }
  }

  async deleteMunicipio(req, res) {
    const id = req.params.id;
    try {
      const eliminado = await municipioService.deleteMunicipio(id);
      if (!eliminado) {
        return res.status(404).json({
          ok: false,
          datos: null,
          mensaje: "Municipio no encontrado",
        });
      }
      return res.status(200).json({
        ok: true,
        datos: null,
        mensaje: "Municipio eliminado correctamente",
      });
    } catch (err) {
      logMensaje("Error en deleteMunicipio:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al eliminar el municipio",
      });
    }
  }
}

module.exports = new MunicipioController();
