// controllers/ordenanzaController.js
const { logMensaje } = require("../utils/logger.js");
const ordenanzaService = require("../services/ordenanzaService");

class OrdenanzaController {

  // Recuperar todas las ordenanzas
  async getAllOrdenanzas(req, res) {
    try {
      const ordenanzas = await ordenanzaService.getAllOrdenanzas();
      return res.status(200).json({
        ok: true,
        datos: ordenanzas,
        mensaje: "Ordenanzas recuperadas correctamente",
      });
    } catch (err) {
      logMensaje("Error en getAllOrdenanzas:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al recuperar ordenanzas",
      });
    }
  }

  // Recuperar ordenanza por ID
  async getOrdenanzaById(req, res) {
    const { id } = req.params;
    try {
      const ordenanza = await ordenanzaService.getOrdenanzaById(id);
      if (!ordenanza) {
        return res.status(404).json({
          ok: false,
          datos: null,
          mensaje: "Ordenanza no encontrada",
        });
      }
      return res.status(200).json({
        ok: true,
        datos: ordenanza,
        mensaje: "Ordenanza recuperada correctamente",
      });
    } catch (err) {
      logMensaje("Error en getOrdenanzaById:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al recuperar la ordenanza",
      });
    }
  }

  // Crear una nueva ordenanza
  async createOrdenanza(req, res) {
    const datosOrdenanza = req.body;

    // Validación mínima de campos obligatorios
    if (!datosOrdenanza.municipio || !datosOrdenanza.nombre || !datosOrdenanza.fecha_aprobacion) {
      return res.status(400).json({
        ok: false,
        datos: null,
        mensaje: "Faltan datos obligatorios para crear la ordenanza",
      });
    }

    try {
      const nuevaOrdenanza = await ordenanzaService.createOrdenanza(datosOrdenanza);
      return res.status(201).json({
        ok: true,
        datos: nuevaOrdenanza,
        mensaje: "Ordenanza creada correctamente",
      });
    } catch (err) {
      logMensaje("Error en createOrdenanza:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al crear la ordenanza",
      });
    }
  }

  // Actualizar una ordenanza existente
  async updateOrdenanza(req, res) {
    const { id } = req.params;
    const datosOrdenanza = req.body;

    try {
      const updatedOrdenanza = await ordenanzaService.updateOrdenanza(id, datosOrdenanza);
      if (!updatedOrdenanza) {
        return res.status(404).json({
          ok: false,
          datos: null,
          mensaje: "Ordenanza no encontrada",
        });
      }
      return res.status(200).json({
        ok: true,
        datos: updatedOrdenanza,
        mensaje: "Ordenanza actualizada correctamente",
      });
    } catch (err) {
      logMensaje("Error en updateOrdenanza:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al actualizar la ordenanza",
      });
    }
  }

  // Eliminar una ordenanza
  async deleteOrdenanza(req, res) {
    const { id } = req.params;
    try {
      const deleted = await ordenanzaService.deleteOrdenanza(id);
      if (!deleted) {
        return res.status(404).json({
          ok: false,
          datos: null,
          mensaje: "Ordenanza no encontrada",
        });
      }
      return res.status(200).json({
        ok: true,
        datos: null,
        mensaje: "Ordenanza eliminada correctamente",
      });
    } catch (err) {
      logMensaje("Error en deleteOrdenanza:", err);
      return res.status(500).json({
        ok: false,
        datos: null,
        mensaje: "Error al eliminar la ordenanza",
      });
    }
  }
}

module.exports = new OrdenanzaController();
