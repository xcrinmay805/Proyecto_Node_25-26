-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: db
-- Tiempo de generación: 31-01-2026 a las 19:28:37
-- Versión del servidor: 8.0.43
-- Versión de PHP: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `administracion_local`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Municipio`
--

CREATE TABLE `Municipio` (
  `id` int NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `densidadPoblacion` double NOT NULL,
  `fundacion` date NOT NULL,
  `gobiernoCoalicion` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Municipio`
--

INSERT INTO `Municipio` (`id`, `nombre`, `densidadPoblacion`, `fundacion`, `gobiernoCoalicion`) VALUES
(17, 'Sevilla', 2000.5, '1500-01-01', 1),
(19, 'Granada', 1500.2, '1492-01-01', 1),
(20, 'Córdoba', 1200, '1523-01-01', 0),
(21, 'Madrid', 2500, '1810-01-06', 0),
(24, 'Jaén', 1050.5, '1400-10-12', 0),
(25, 'Córdoba', 1230.5, '1414-10-10', 1),
(26, 'Salamanca', 2400.5, '1300-05-19', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Ordenanza`
--

CREATE TABLE `Ordenanza` (
  `id_ordenanza` int NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `voto_favorable` float NOT NULL,
  `fecha_aprobacion` date NOT NULL,
  `vigente` tinyint(1) NOT NULL,
  `municipio` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Ordenanza`
--

INSERT INTO `Ordenanza` (`id_ordenanza`, `nombre`, `voto_favorable`, `fecha_aprobacion`, `vigente`, `municipio`) VALUES
(1, 'Ordenanza B', 90, '2026-01-14', 0, 19),
(6, 'Ordenanza D', 70, '1909-11-11', 1, 17),
(7, 'Recogida de basura', 95.5, '1978-01-15', 0, 20);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Municipio`
--
ALTER TABLE `Municipio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `Ordenanza`
--
ALTER TABLE `Ordenanza`
  ADD PRIMARY KEY (`id_ordenanza`),
  ADD KEY `municipio_ordenanza_fk` (`municipio`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Municipio`
--
ALTER TABLE `Municipio`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `Ordenanza`
--
ALTER TABLE `Ordenanza`
  MODIFY `id_ordenanza` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Ordenanza`
--
ALTER TABLE `Ordenanza`
  ADD CONSTRAINT `municipio_ordenanza_fk` FOREIGN KEY (`municipio`) REFERENCES `Municipio` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
