const Sequelize = require('sequelize');

module.exports = function(sequelize,DataTypes){
    return sequelize.define('ordenanza',{
        id_ordenanza:{
            autoIncrement: true,
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        nombre:{
            type: DataTypes.STRING(40),
            allowNull: false,
        },
        voto_favorable:{
            type: DataTypes.DECIMAL(8,2),
            allowNull: false,
        },
        fecha_aprobacion:{
            type: DataTypes.DATEONLY,
            allowNull: false,
        },
        vigente:{
            type: DataTypes.BOOLEAN,
            allowNull: false,
        },
        municipio:{
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
            model: 'municipio',
            key: 'id'
      }
        }
    },{
        sequelize,
        tableName: 'Ordenanza',
        timestamps: false,
        indexes:[{
            name: "PRIMARY",
            unique: true,
            using: "BTREE",
            fields:[{
                name: "id_ordenanza"
            },]
        },
        {
        name: "municipio",
        using: "BTREE",
        fields: [
          { name: "municipio" },
        ]
      },]
    });
};