var DataTypes = require("sequelize").DataTypes;
var _municipio = require("./municipio");
var _ordenanza = require("./ordenanza");

function initModels(sequelize) {
  var municipio = _municipio(sequelize, DataTypes);
  var ordenanza = _ordenanza(sequelize, DataTypes);

  // Relación correcta
  ordenanza.belongsTo(municipio, { as: "municipioData", foreignKey: "municipio" });
  municipio.hasMany(ordenanza, { as: "ordenanzas", foreignKey: "municipio" });

  return {
    municipio,
    ordenanza,
  };
}

module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
